import board
import busio
import adafruit_esp32spi.adafruit_esp32spi_socket as socket
from adafruit_esp32spi import adafruit_esp32spi
import adafruit_requests as requests
import digitalio
import neopixel
import time
import adafruit_datetime as datetime
import adafruit_ht16k33.matrix as matrix

# Initialize ESP32 SPI communication
spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
esp32_cs = digitalio.DigitalInOut(board.D10)
esp32_ready = digitalio.DigitalInOut(board.D9)
esp32_reset = digitalio.DigitalInOut(board.D6)
esp = adafruit_esp32spi.ESP_SPIcontrol(spi, esp32_cs, esp32_ready, esp32_reset)

# Initialize Wi-Fi connection
while not esp.is_connected:
    try:
        esp.connect_AP('YOUR_WIFI_SSID', 'YOUR_WIFI_PASSWORD')
    except RuntimeError as e:
        print("could not connect to AP, retrying: ",e)
        continue
print("Connected to", str(esp.ssid, 'utf-8'), "\tRSSI:", esp.rssi)

# Construct the URL for the API endpoint
latitude = 37.518340
longitude = -77.506780
url = f"https://api.weather.gov/points/{latitude},{longitude}"

# Fetch data from the API endpoint
response = None
try:
    socket.set_interface(esp)
    requests.set_socket(socket, esp)
    response = requests.get(url)
except Exception as e:
    print("Error fetching data:", e)
    
if response is not None and response.status_code == 200:
    try:
        data = response.json()
        forecast_url = data['properties']['forecast']
        forecast_response = requests.get(forecast_url)
        if forecast_response.status_code == 200:
            forecast_data = forecast_response.json()
            print("Forecast data fetched successfully.")
            
            # Initialize RGB matrix display
            i2c = busio.I2C(board.SCL, board.SDA)
            matrix = matrix.Matrix8x8x2(i2c)
            
            # Display forecast on RGB matrix
            for i in range(10):
                forecast_date = datetime.datetime.strptime(forecast_data['properties']['periods'][i]['startTime'],
                                                            '%Y-%m-%dT%H:%M:%S%z')
                forecast = forecast_data['properties']['periods'][i]['detailedForecast']
                message = f"{forecast_date.strftime('%Y-%m-%d')}: {forecast}"
                
                # Display message on matrix
                matrix.fill(0)
                matrix.text(message, 0, 0, 1)
                matrix.show()
                time.sleep(5)  # Display each forecast for 5 seconds
                
        else:
            print("Failed to fetch forecast data.")
    except Exception as e:
        print("Error processing data:", e)
else:
    print("Failed to fetch location data.")
